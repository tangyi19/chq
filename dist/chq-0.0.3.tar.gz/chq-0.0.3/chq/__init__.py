name = "fuckchq"

def hacksatellite():
    return "Congratulations!\nhack satellite successfully!"

def hackwebsite():
    return "Congratulations!\nHack website successfully!\namdin = \"chq\"\npassword = \"fuckchq\""

def hackpentagon():
    return "Congratulations!\nhack the Pentagon successfully!"

def getflag():
    return "flag{e2086d3031290066b35b40b2e9f79d4c}"
