# HACKTOOL

**Anybody can fuck a satellite/website by this one-click package.**

**CTFer can print the flag in CTF competitions automatically**

